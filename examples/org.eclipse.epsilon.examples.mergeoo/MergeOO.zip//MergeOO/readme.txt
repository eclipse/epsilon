To run this EML merging right-click metamodels/OO.ecore and click "Register EPackages".
Then, double-click MergeOO.launch and then go to Run->Open Run Dialog..., select MergeOO
and click Run.